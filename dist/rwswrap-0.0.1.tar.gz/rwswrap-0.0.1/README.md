# A Robot Web Services wrapper
A small wrapper I needed as part of my master's thesis
